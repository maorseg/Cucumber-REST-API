'use strict';

module.exports = require('../../../apickli/apickli-gherkin');
// C:\Users\דדי ואור\Desktop\automation\Cucumber_REST_API\cucumber-api-example2\source\apickli
