/* eslint new-cap: "off", no-invalid-this: "off" */

'use strict';


const apickli = require('../../../apickli/apickli.js');
const {Before, setDefaultTimeout} = require('cucumber');

// Tested: https://reqres.in/ - Test your front-end against a real API
Before(function() {
  this.apickli = new apickli.Apickli('https', 'reqres.in');
//  this.apickli.addRequestHeader('Cache-Control', 'no-cache');
//  this.apickli.clientTLSConfig = {
 //   valid: {
   //   key: './test/mock_target/certs/client-key.pem',
   //   cert: './test/mock_target/certs/client-crt.pem',
   //   ca: './test/mock_target/certs/ca-crt.pem',
  //  },
 // };
});

// default step timeout in ms
setDefaultTimeout(60 * 1000); 
